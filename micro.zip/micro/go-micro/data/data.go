// Package data is an interface for data access
package data
